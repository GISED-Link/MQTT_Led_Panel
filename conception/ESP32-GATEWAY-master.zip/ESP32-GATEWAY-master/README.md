# ESP32-GATEWAY
ESP32 WiFi / BLE development board with Ethernet, microSD card, GPIOs made with KiCAD
