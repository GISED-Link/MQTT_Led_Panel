# ESP32-EVB

ESP32 wifi / BLE development board with Ethernet, relays, microSD card, CAN, infrared, Li-Po charger, GPIOs.

Open-source hardware board made with open-source CAD software. Comes with ESP32-WROOM32 module.

https://www.olimex.com/Products/IoT/ESP32/ESP32-EVB/open-source-hardware



