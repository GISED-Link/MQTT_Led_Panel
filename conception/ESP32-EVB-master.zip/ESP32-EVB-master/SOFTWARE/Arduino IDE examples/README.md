Arduino IDE would not work with ESP32 boards out-the-box. You need to first install ESP32 support, follow the advice here: 

https://docs.espressif.com/projects/arduino-esp32/en/latest/installing.html

ESP32-EVB and the rest of the Olimex-made ESP32 boards are supported by Arduino-ESP32, so no extra steps are needed.