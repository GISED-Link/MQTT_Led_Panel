# CAN DEMO Code Example

Starts a CAN demo to receive Standard Frames
if there is test frame set in Kconfig ( menuconfig ) 
there is also send a test frame.

# Note:

Olimex EVB Rev B 

Rx CAN = GPIO 35

Tx CAN = GPIO  5 


See the README.md file in the components CAN directory for more information about 
CAN Driver Pack.

# credit 

# CAN Driver 
by Thomas Bart, 

http://www.barth-dev.de/

Repo: https://github.com/ThomasBarth/ESP32-CAN-Driver

# CAN Driver Pack ESP-IDF 
by Rudi Wagner, rudi ;-) 

http://esp32.de

Repo: https://github.com/ESP32DE/ESP32-CAN-Driver/tree/Component_CAN_Driver_Pack

# DEMO code for CAN Driver Pack 

https://github.com/ESP32DE/ESP32-CAN-Driver/tree/DEMO_CAN



# look allways first to the origin's

https://github.com/ThomasBarth/ESP32-CAN-Driver

https://github.com/ESP32DE/ESP32-CAN-Driver/tree/Component_CAN_Driver_Pack

https://github.com/ESP32DE/ESP32-CAN-Driver/tree/DEMO_CAN

