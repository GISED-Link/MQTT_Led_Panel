Demo example for Olimex ESP32-EVB with Olimex MOD-RTC connected to the UEXT.

Used I2C-1 for communication between the host board and the module. You can find more information in the comments in the main.c file.

After programming on the terminal you will see the date and time updated each second. By default it is set to 28 February 2020; 23:59:50 (you can change that in code).

Stanimir Petev
2018/03/16